package com.example.blutooth4;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class MainActivity extends Activity {
    private volatile String lastReceivedData = "";
    private Button connectButton;
    private TextView connectionStatus;
    private TextView receivedDataText;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private static final UUID HC_05_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // HC-05's UUID
    private InputStream mmInStream;
    private Handler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connectButton = findViewById(R.id.connectButton);
        connectionStatus = findViewById(R.id.connectionStatus);
        receivedDataText = findViewById(R.id.receivedData);

        TextView txtget = findViewById(R.id.receivedText);
        Button btnget = findViewById(R.id.getText);
        Button btnAct = findViewById(R.id.openActi);

        btnAct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

        btnget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtget.setText(lastReceivedData);
                sendResetCommand();
            }
        });

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    String data = (String) msg.obj;
                    if (!data.equals(lastReceivedData)) {
                        receivedDataText.setText(data);
                        lastReceivedData = data;
                        System.out.println(data); // received data
                    }
                }
            }
        };

        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bluetoothAdapter != null) {
                    BluetoothDevice hc05 = bluetoothAdapter.getRemoteDevice("98:D3:61:F7:13:83");

                    try {
                        // Attempt to create and connect the Bluetooth socket
                        socket = hc05.createRfcommSocketToServiceRecord(HC_05_UUID);
                        socket.connect();
                        connectionStatus.setText("Status: Connected");

                        mmInStream = socket.getInputStream();
                        beginListenForData();

                    } catch (IOException e) {
                        // Handle connection failure
                        Toast.makeText(getApplicationContext(), "Connection failed.", Toast.LENGTH_SHORT).show();
                        try {
                            // Attempt to close the socket to release resources
                            socket.close();
                        } catch (IOException closeException) {
                            closeException.printStackTrace();
                        }
                    }
                } else {
                    // Handle the case where Bluetooth is not available on the device
                    Toast.makeText(getApplicationContext(), "Bluetooth is not available on this device.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void beginListenForData() {
        final byte delimiter = 10; // newline character
        Thread thread = new Thread(new Runnable() {
            public void run() {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        int bytesAvailable = mmInStream.available();
                        if (bytesAvailable > 0) {
                            byte[] packetBytes = new byte[bytesAvailable];
                            mmInStream.read(packetBytes);
                            String data = new String(packetBytes, 0, bytesAvailable);
                            Message msg = mHandler.obtainMessage(0, data);
                            msg.sendToTarget();
                        }
                    } catch (IOException e) {
                        // Handle any data reception or socket errors
                        e.printStackTrace();
                        break;
                    }
                }
            }
        });
        thread.start();
    }

    private void sendResetCommand() {
        if (socket != null && socket.isConnected()) {
            try {
                OutputStream outputStream = socket.getOutputStream();
                outputStream.write('R'); // Sending 'R' to reset the Arduino
                Toast.makeText(getApplicationContext(), "Reset command sent.", Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "Failed to send reset command.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(getApplicationContext(), "Bluetooth connection not available.", Toast.LENGTH_SHORT).show();
        }
    }
}
