package com.example.blutooth4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity2 extends AppCompatActivity {

    private static final long TIME_DELAY = 30000; // 30 seconds of inactivity
    private MediaPlayer mediaPlayer;
    private Handler handler;
    private boolean userInteracted;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mediaPlayer = MediaPlayer.create(this, R.raw.backgroun_music);
        mediaPlayer.setLooping(true); // Loop the background music
        mediaPlayer.start(); // Start playing the background music

        handler = new Handler(Looper.myLooper());

        // Start the countdown when the activity is created or resumed
        startCountdown();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start(); // Resume playing the background music if it's not playing
        }
        startCountdown();
    }

    @Override
    public void onPause() {
        super.onPause();
        stopCountdown();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause(); // Pause the background music on activity pause
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release(); // Release MediaPlayer resources when the activity is destroyed
        }
    }

    private void startCountdown() {
        handler.postDelayed(closeActivityRunnable, TIME_DELAY);
    }

    private void stopCountdown() {
        handler.removeCallbacks(closeActivityRunnable);
    }

    private final Runnable closeActivityRunnable = new Runnable() {
        @Override
        public void run() {
            // Close the activity due to inactivity
            finish();
        }
    };
}